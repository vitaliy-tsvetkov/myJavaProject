import java.lang.reflect.Array;
import java.util.Arrays;

/*
Jaden Smith, the son of Will Smith, is the star of films such as The Karate Kid (2010) and After Earth (2013).
Jaden is also known for some of his philosophy that he delivers via Twitter.
When writing on Twitter, he is known for almost always capitalizing every word.

Your task is to convert strings to how they would be written by Jaden Smith.
The strings are actual quotes from Jaden Smith, but they are not capitalized in the same way he originally typed them.

Example:

Not Jaden-Cased: "How can mirrors be real if our eyes aren't real"
Jaden-Cased:     "How Can Mirrors Be Real If Our Eyes Aren't Real"

Note that the Java version expects a return value of null for an empty string or null.

*/
public class JadenCase {

    public String toJadenCase(String phrase) {
        String str = "";
        if (phrase == null || phrase.isEmpty()) {
            return null;
        } else {
            String arr[] = phrase.split(" ");

            for (int i = 0; i < Array.getLength(arr); i++) {
                String str1 = arr[i];
                String subArr[] = str1.split("");

                String replace = "";
                replace += str1.charAt(0);
                replace = replace.toUpperCase();
                subArr[0] = replace;

                String temp = "";

                int substrLength = str1.length();
                for (int j = 0; j < substrLength; j++) {
                    temp += subArr[j];
                }
                arr[i] = temp;
            }
            for (int k = 0; k < Array.getLength(arr); k++) {
                if (k == Array.getLength(arr) - 1) {
                    str += arr[k];
                } else {
                    str += arr[k] + " ";
                }
            }
            return str;
        }
    }


}
